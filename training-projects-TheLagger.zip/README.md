# Práctica para curso de introducción a Angular

## TrainingProjects

- [Sprint W1 - Application structure](/sprint-week-1.md)
- [Sprint W2 - Routes and layout](/sprint-week-2.md)
- [Sprint W3 - Data Management](/sprint-week-3.md)
- [Sprint W4 - Http communications](/sprint-week-4.md)
- [Sprint W5 - User experience](/sprint-week-5.md)